/** Shane Tonkin- 2791399 - Etude 11
  * This program checks to see if it is
  * possible to make given target number from a set 
  * of given numbers using a combination of * and +
  * using either Normal or Left to Right operations.
  */ 
package Etude11;

import java.util.Scanner;
import java.util.ArrayList;
@SuppressWarnings("unchecked")

public class ArithmeticTree{
  
  public static boolean stop;
  
  public static ArrayList<Integer> outcomes = new ArrayList<Integer>();
  
  /**This method checks whether it is possible to sum
    * to the target number fromthe given set of numbers
    * @param ArrayList<Integer> nums : the ArrayList of numbers to use
    * @param int target : the target number
    */
  static void checkNormalMath(ArrayList<Integer> nums, int target, int index, Node parent){
    if(stop){
      return;
    }
     //Base Case
    if(index == 0){
      Node<Integer> root = new Node<>(nums.get(0));
      root.isRoot();
      //System.out.println(root.getData());
      parent = root;
      index++;
      checkNormalMath(nums, target, index, root);
    }//Exit Case
    else if(index == nums.size()-1){
      int value = (Integer) parent.getData();
      Node<Integer> add = new Node<Integer>(value + nums.get(index), parent);
      add.setAdd();
      //System.out.print(add.getData() + " ");
      int a = 1;
      Node<Integer> times = new Node<Integer>(0, parent);
      int addValue = findLastAdd(nums, times, index, a);
      times.setData(addValue);
      //System.out.print(times.getData() + " ");
      outcomes.add(value + nums.get(index));
      outcomes.add(addValue);
      if(addValue == target){
        String toPrint = "";
        stop = true;
        System.out.println(getNString(nums, times, index, toPrint, target));
        return;
      }else if(value + nums.get(index) == target){
        String toPrint = "";
        stop = true;
        System.out.println(getNString(nums, add, index, toPrint, target));
        return;
      }
    }//Other Cases
    else if(index != (nums.size()-1) && !stop){
      int value = (Integer) parent.getData();
      Node<Integer> add = new Node<Integer>(value + nums.get(index), parent);
      add.setAdd();
      //System.out.print(add.getData() + " ");
      int a = 1;
      Node<Integer> times = new Node<Integer>(0, parent);
      int addValue = findLastAdd(nums, times, index, a);
      times.setData(addValue);
      //System.out.print(times.getData() + " ");
      //System.out.println();
      index++;
      if((Integer) add.getData() <= target || !stop){
        checkNormalMath(nums, target, index, add);
      }
      if((Integer) times.getData() <= target || !stop){
        checkNormalMath(nums, target, index, times);
      } 
    }
    return;
  }
  
  /**This method checks whether it is possible to sum
    * to the target number fromthe given set of numbers
    * @param ArrayList<Integer> nums : the ArrayList of numbers to use
    * @param int target : the target number
    */
  static void checkLRMath(ArrayList<Integer> nums, int target, int index, Node parent){
    if(stop){
      return;
    }
    //Base Case
    if(index == 0){
      Node<Integer> root = new Node<Integer>(nums.get(0));
      root.isRoot();
      //System.out.println(root.getData());
      parent = root;
      index++;
      checkLRMath(nums, target, index, root);
    }//Exit Case
    else if(index == nums.size()-1 && !stop){
      int value = (Integer) parent.getData();
      Node<Integer> add = new Node<Integer>(value + nums.get(index), parent);
      add.setAdd();
      //System.out.print(add.getData() + " ");
      Node<Integer> times = new Node<Integer>(value * nums.get(index),parent);
      // System.out.print(times.getData() + " ");
      outcomes.add(value * nums.get(index));
      outcomes.add(value + nums.get(index));
      if(value * nums.get(index) == target){
        String toPrint = "";
        System.out.println(getLRString(nums, times, index, toPrint, target));
        stop = true;
        return;
      }else if(value + nums.get(index) == target){
        String toPrint = "";
        System.out.println(getLRString(nums, add, index, toPrint, target));
        stop = true;
        return;
      }
      return;
    }//Other Cases
    else if(index != (nums.size()-1) && !stop){
      int value = (Integer) parent.getData();
      Node<Integer> add = new Node<Integer>(value + nums.get(index), parent);
      //System.out.print(add.getData() + " ");
      add.setAdd();
      Node<Integer> times = new Node<Integer>(value * nums.get(index), parent);
      //System.out.print(times.getData());
      //System.out.println();
      index++;
        if((Integer) add.getData() <= target){
        checkLRMath(nums, target, index, add);
      }
      if((Integer) times.getData() <= target){
        checkLRMath(nums, target, index, times);
      } 
    } 
    return;
  }
  
  public static int findLastAdd(ArrayList<Integer> nums, Node n, int i, int value){
    value = nums.get(i);
    while(n.getParent() != null){
      if(n.getAdd()){
        return (Integer) n.getParent().getData() + value;
      }else{
        value *= nums.get(i-1);
        i --;
      }
      n = n.getParent();
    }
    return value;
  }
  
  public static String getNString(ArrayList<Integer> nums, Node current,int index, String toPrint, int target){
    //Base case
    if(index == nums.size()-1 && current.getParent() != null){
      if(current.getAdd()){
        toPrint += toPrint + " + ";
      }else{
        toPrint += " * ";
      }
      index -= 1;
      toPrint += nums.get(nums.size()-1);
      toPrint = getNString(nums, current.getParent(), index, toPrint, target);
      return toPrint;
    }//Exit case
    else if(index == 0){
      toPrint = "N "+ target + " " +nums.get(index) + toPrint;
      return toPrint;
    }else{
      if(current != null){
        index -= 1;
        if(current.getAdd()){
          toPrint = " + "+ nums.get(index+1) + toPrint;
          toPrint =  getNString(nums, current.getParent(), index--, toPrint, target);// + toPrint;
        }else{
          toPrint = " * "+ nums.get(index+1) + toPrint;
          toPrint = getNString(nums, current.getParent(), index--, toPrint, target);//+  toPrint;
        }
      }
    }
    return toPrint;
  }
  
  public static String getLRString(ArrayList<Integer> nums, Node current,int index, String toPrint, int target){
    //Base case
    if(index == nums.size()-1 && current.getParent() != null){
      if(current.getAdd()){
        toPrint += toPrint + " + ";
      }else{
        toPrint += " * ";
      }
      index -= 1;
      toPrint += nums.get(nums.size()-1);
      toPrint = getLRString(nums, current.getParent(), index, toPrint, target);
      return toPrint;
    }//Exit case
    else if(index == 0){
      toPrint = "L "+ target + " " +nums.get(index) + toPrint;
      return toPrint;
    }else{
      if(current != null){
        index -= 1;
        if(current.getAdd()){
          toPrint = " + "+ nums.get(index+1) + toPrint;
          toPrint =  getLRString(nums, current.getParent(), index--, toPrint, target);// + toPrint;
        }else{
          toPrint = " * "+ nums.get(index+1) + toPrint;
          toPrint = getLRString(nums, current.getParent(), index--, toPrint, target);//+  toPrint;
        }
      }
    }
    return toPrint;
  }
  
  
  
  public static void main(String[] args){
    //variable decleration
    int target = 0;
    int i = 0;
    int j = 2;
    Boolean normal = true;
    String secondLine = " ";
    ArrayList<Integer> numbers = new ArrayList<Integer>();
    
    Scanner sc = new Scanner(System.in);
    while(sc.hasNextLine() && j < 3){
      while(sc.hasNextInt()){
        numbers.add(sc.nextInt());
        i++;
      }
      secondLine = sc.nextLine();
      i = 0;
      target = numbers.remove(numbers.size()-1);
      if(secondLine.contains(" N")){
        normal = true;
      }else{
        normal = false;
      }
      stop = false;
      
      if(normal== true && numbers.size() > 1){
        checkNormalMath(numbers, target, 0, null);
        if(!outcomes.contains(target)){
          System.out.println("N "+ target + " Impossible");
        }
      }else if (numbers.size() > 1){
        checkLRMath(numbers, target, 0, null);
        if(!outcomes.contains(target)){
          System.out.println("L "+target+" Impossible");
        }
      }else if (normal == true && numbers.size() == 1){
        if(numbers.get(0) == target){
          System.out.println("N " + target +" "+target);
        }else{
          System.out.println("N "+target + " Impossible");
        }
      }else{
        if(numbers.get(0) == target){
          System.out.println("L " + target +" "+target);
        }else{
          System.out.println("L "+target + " Impossible");
        }
      }
        
      //Reset the ArrayLists
      numbers.clear();
      outcomes.clear();
      stop = false;
    }
  }
}